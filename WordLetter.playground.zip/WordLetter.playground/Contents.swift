import UIKit

class Program
{
    func find (word : String, letter : Character)
    {
        var count = 0
        
        for l in word
        {
            if l == letter
            {
                count = count + 1
            }
        }
        
        let result = "This expression contains \(count) pieces letter of \(letter)"
        print(result)
    }
}

let x = Program()
x.find(word: "nursemanakiboglu", letter: "n")


    

